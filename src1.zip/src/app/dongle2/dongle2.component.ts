import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dongle2',
  templateUrl: './dongle2.component.html',
  styleUrls: ['./dongle2.component.css']
})
export class Dongle2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
