import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaidcard',
  templateUrl: './postpaidcard.component.html',
  styleUrls: ['./postpaidcard.component.css']
})
export class PostpaidcardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
