import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { CorporateloginComponent } from './corporatelogin/corporatelogin.component';
import { CreateanaccountComponent } from './createanaccount/createanaccount.component';
import { PrepaidComponent } from './prepaid/prepaid.component';
import { PostpaidComponent } from './postpaid/postpaid.component';
import { DongleComponent } from './dongle/dongle.component';
import { NewpasswordComponent } from './newpassword/newpassword.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { RouterModule } from '@angular/router';
import { PayComponent } from './pay/pay.component';
import { PortnumberComponent } from './portnumber/portnumber.component';
import { Prepaid1Component } from './prepaid1/prepaid1.component';
import { Prepaid2Component } from './prepaid2/prepaid2.component';
import { Prepaid3Component } from './prepaid3/prepaid3.component';
import { Postpaid1Component } from './postpaid1/postpaid1.component';
import { Postpaid2Component } from './postpaid2/postpaid2.component';
import { Postpaid3Component } from './postpaid3/postpaid3.component';
import { Dongle1Component } from './dongle1/dongle1.component';
import { Dongle2Component } from './dongle2/dongle2.component';
import { Dongle3Component } from './dongle3/dongle3.component';
import { ServicesComponent } from './services/services.component';
import { PrepaidcardComponent } from './prepaidcard/prepaidcard.component';
import { PostpaidcardComponent } from './postpaidcard/postpaidcard.component';
import { DonglecardComponent } from './donglecard/donglecard.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SidebarComponent } from './sidebar/sidebar.component';





@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AboutUsComponent,
    ContactUsComponent,
    CustomerloginComponent,
    CorporateloginComponent,
    ForgotpasswordComponent,
    CreateanaccountComponent,
    PrepaidComponent,
    PostpaidComponent,
    DongleComponent,
    NewpasswordComponent,
    PagenotfoundComponent,
    PayComponent,
    PortnumberComponent,
    Prepaid1Component,
    Prepaid2Component,
    Prepaid3Component,
    Postpaid1Component,
    Postpaid2Component,
    Postpaid3Component,
    Dongle1Component,
    Dongle2Component,
    Dongle3Component,
    ServicesComponent,
    PrepaidcardComponent,
    PostpaidcardComponent,
    DonglecardComponent,
    SidebarComponent,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {path:'**',component:PagenotfoundComponent}
    ]),
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
