import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Prepaid2Component } from './prepaid2.component';

describe('Prepaid2Component', () => {
  let component: Prepaid2Component;
  let fixture: ComponentFixture<Prepaid2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Prepaid2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Prepaid2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
