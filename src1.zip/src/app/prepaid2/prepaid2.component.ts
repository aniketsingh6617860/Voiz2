import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaid2',
  templateUrl: './prepaid2.component.html',
  styleUrls: ['./prepaid2.component.css']
})
export class Prepaid2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
