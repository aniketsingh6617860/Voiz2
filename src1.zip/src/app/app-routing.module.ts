import { NgModule } from '@angular/core';
import { flush } from '@angular/core/testing';
import { RouterModule, Routes } from '@angular/router';
import { Sidebar } from 'ng-sidebar';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CorporateloginComponent } from './corporatelogin/corporatelogin.component';
import { CreateanaccountComponent } from './createanaccount/createanaccount.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { DongleComponent } from './dongle/dongle.component';
import { FooterComponent } from './footer/footer.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { NewpasswordComponent } from './newpassword/newpassword.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { PayComponent } from './pay/pay.component';
import { PortnumberComponent } from './portnumber/portnumber.component';
import { PostpaidComponent } from './postpaid/postpaid.component';
import { PrepaidComponent } from './prepaid/prepaid.component';
import { Prepaid1Component } from './prepaid1/prepaid1.component';
import { Prepaid2Component } from './prepaid2/prepaid2.component';
import { Prepaid3Component } from './prepaid3/prepaid3.component';
import { ServicesComponent } from './services/services.component';
import { SidebarComponent } from './sidebar/sidebar.component';

const routes: Routes = [
  {path: 'header',component:HeaderComponent},
  {path: 'footer',component:FooterComponent},
  {path: 'aboutus',component:AboutUsComponent},
  {path: 'home' , component:HomeComponent},
  {path: 'contactus' ,component:ContactUsComponent},
  {path: 'customerlogin',component:CustomerloginComponent},
  {path: 'corporatelogin',component:CorporateloginComponent},
  {path: 'createanaccount',component:CreateanaccountComponent},
  {path: 'forgotpassword',component:ForgotpasswordComponent},
  {path: 'prepaid',component:PrepaidComponent},
  {path: 'postpaid',component:PostpaidComponent},
  {path: 'dongle',component:DongleComponent},
  {path: 'newpassword',component:NewpasswordComponent},
  {path: 'pagenotfound',component:PagenotfoundComponent},
  {path: 'pay',component:PayComponent},
  {path: 'portnumber',component:PortnumberComponent},
  {path: 'prepaid1',component:Prepaid1Component},
  {path: 'prepaid2',component:Prepaid2Component},
  {path: 'prepaid3',component:Prepaid3Component},
  {path: 'postpaid1',component:Prepaid3Component},
  {path: 'postpaid2',component:Prepaid3Component},
  {path: 'postpaid3',component:Prepaid3Component},
  {path: 'dongle1',component:Prepaid3Component},
  {path: 'dongle2',component:Prepaid3Component},
  {path: 'dongle3',component:Prepaid3Component},
  {path: 'sidebar',component:SidebarComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
