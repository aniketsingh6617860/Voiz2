import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaid3',
  templateUrl: './prepaid3.component.html',
  styleUrls: ['./prepaid3.component.css']
})
export class Prepaid3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
