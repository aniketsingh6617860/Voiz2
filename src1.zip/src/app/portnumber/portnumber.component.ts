import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portnumber',
  templateUrl: './portnumber.component.html',
  styleUrls: ['./portnumber.component.css']
})
export class PortnumberComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
