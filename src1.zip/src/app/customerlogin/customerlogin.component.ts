import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
