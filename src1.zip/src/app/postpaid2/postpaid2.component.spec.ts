import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Postpaid2Component } from './postpaid2.component';

describe('Postpaid2Component', () => {
  let component: Postpaid2Component;
  let fixture: ComponentFixture<Postpaid2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Postpaid2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Postpaid2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
