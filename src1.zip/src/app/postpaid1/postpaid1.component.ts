import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaid1',
  templateUrl: './postpaid1.component.html',
  styleUrls: ['./postpaid1.component.css']
})
export class Postpaid1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
