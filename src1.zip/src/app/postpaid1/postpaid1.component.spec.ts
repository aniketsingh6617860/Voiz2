import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Postpaid1Component } from './postpaid1.component';

describe('Postpaid1Component', () => {
  let component: Postpaid1Component;
  let fixture: ComponentFixture<Postpaid1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Postpaid1Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Postpaid1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
