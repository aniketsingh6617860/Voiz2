import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaid1',
  templateUrl: './prepaid1.component.html',
  styleUrls: ['./prepaid1.component.css']
})
export class Prepaid1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
