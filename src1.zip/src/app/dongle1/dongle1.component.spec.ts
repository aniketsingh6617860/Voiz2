import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Dongle1Component } from './dongle1.component';

describe('Dongle1Component', () => {
  let component: Dongle1Component;
  let fixture: ComponentFixture<Dongle1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Dongle1Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Dongle1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
