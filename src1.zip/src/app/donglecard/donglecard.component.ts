import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donglecard',
  templateUrl: './donglecard.component.html',
  styleUrls: ['./donglecard.component.css']
})
export class DonglecardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
