import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Postpaid3Component } from './postpaid3.component';

describe('Postpaid3Component', () => {
  let component: Postpaid3Component;
  let fixture: ComponentFixture<Postpaid3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Postpaid3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Postpaid3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
